<template>
  <div class="inputField">

  </div>
</template>

<script>
export default {
  name: "InputField"
}
</script>

<style scoped>

</style>